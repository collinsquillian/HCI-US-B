# UDPReceive

Assignment V: Implementing a GPS visualisation for smart homes based on user maps.

A UDP terminal is used to simulate GPS input from a mobile device.
